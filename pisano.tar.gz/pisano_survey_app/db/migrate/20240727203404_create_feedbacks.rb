class CreateFeedbacks < ActiveRecord::Migration[6.0]
  def change
    create_table :feedbacks, id: :uuid do |t|
      t.references :survey, type: :uuid, foreign_key: true

      t.timestamps
    end
  end
end
