class CreateOptions < ActiveRecord::Migration[6.0]
  def change
    create_table :options, id: :uuid do |t|
      t.text :title
      t.references :question, type: :uuid, foreign_key: true

      t.timestamps
    end
  end
end
