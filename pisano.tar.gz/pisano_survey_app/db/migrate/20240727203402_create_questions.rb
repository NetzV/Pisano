class CreateQuestions < ActiveRecord::Migration[6.0]
  def change
    create_table :questions, id: :uuid do |t|
      t.text :title
      t.integer :question_type, default: 0
      t.references :survey, type: :uuid, foreign_key: true

      t.timestamps
    end
  end
end
