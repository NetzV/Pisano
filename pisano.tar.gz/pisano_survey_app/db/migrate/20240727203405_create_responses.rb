class CreateResponses < ActiveRecord::Migration[6.0]
  def change
    create_table :responses, id: :uuid do |t|
      t.references :question, type: :uuid, foreign_key: true
      t.text :body
      t.references :option, type: :uuid, foreign_key: true
      t.references :feedback, type: :uuid, foreign_key: true

      t.timestamps
    end
  end
end
