survey = Survey.create(name: 'Customer Satisfaction Survey')
question1 = survey.questions.create(title: 'How was your experience with us today?', question_type: :choice)
%w[Very Good Good Neutral Bad Very Bad].each do |option|
  question1.options.create(title: option)
end
question2 = survey.questions.create(title: 'Please explain the reason for your choice', question_type: :text)
