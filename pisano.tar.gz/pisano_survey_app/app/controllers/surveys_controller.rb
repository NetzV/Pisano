class SurveysController < ApplicationController
def show
    survey = Survey.find(params[:id])
    render json: survey.as_json(include: { questions: { include: :options } })
  end

  def create
    survey = Survey.new(survey_params)
    if survey.save
      render json: survey, status: :created
    else
      render json: survey.errors, status: :unprocessable_entity
    end
  end

  private

  def survey_params
    params.require(:survey).permit(:name, questions_attributes: [:title, :question_type, options_attributes: [:title]])
  end
end
