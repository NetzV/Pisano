class FeedbacksController < ApplicationController
 def create
    survey = Survey.find(params[:survey_id])
    feedback = survey.feedbacks.new
    if feedback.save
      responses_params.each do |response_param|
        feedback.responses.create(response_param)
      end
      render json: feedback, status: :created
    else
      render json: feedback.errors, status: :unprocessable_entity
    end
  end

  private

  def responses_params
    params.require(:responses).map do |response|
      response.permit(:question_id, :body, :option_id)
    end
  end
end
