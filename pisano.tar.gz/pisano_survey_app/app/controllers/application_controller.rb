class ApplicationController < ActionController::API
end
