Rails.application.routes.draw do
  resources :surveys, only: [:show, :create] do
    post 'feedback', to: 'feedbacks#create'
  end
end
